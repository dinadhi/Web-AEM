$(function(){
    $("#nav-edit").prependTo("header");
});
