function optionsForGalleryViewer(src) {
    return {
        arrows: false,
        asNavFor: $(src).find('.gallery-slides'),
        dots: false,
        fade: true,
        slidesToScroll: 1,
        slidesToShow: 1,
    };
}

function baseOptionsForGallerySlides(src) {
    return {
        arrows: false,
        adaptiveHeight: true,
        asNavFor: $(src).find('.gallery-viewer'),
        dots: false,
        focusOnSelect: true,
        slidesToScroll: 1,
        slidesToShow: 3,
        centerMode: false,
        mobileFirst: true,
        responsive: []
    };
}

function optionsForGalleryColumn(src) {
    var options = baseOptionsForGallerySlides(src);

    options.responsive.push({
        breakpoint: 767,
        settings: { slidesToShow: 3, }
    });

    options.responsive.push({
        breakpoint: 991,
        settings: { slidesToShow: 5, }
    });
    return options;
}

function optionsForGalleryFull(src) {
    var options = baseOptionsForGallerySlides(src);
    options.responsive.push({
        breakpoint: 767,
        settings: {
            slidesToShow: 3,
            vertical: true
        }
    });
    options.responsive.push({
        breakpoint: 1199,
        settings: {
            slidesToShow: 4,
            vertical: true
        }
    });
    return options;
}

function optionsForGalleryModal(src) {
    var options = baseOptionsForGallerySlides(src);
    options.responsive.push({
        breakpoint: 767,
        settings: {
            slidesToShow: 3,
            vertical: true
        }
    });
    options.responsive.push({
        breakpoint: 1199,
        settings: {
            slidesToShow: 4,
            vertical: true
        }
    });
    return options;
}


$(function(){

    $('.gallery-full').each(function(){
        $(this).find('.gallery-viewer').slick(optionsForGalleryViewer(this));
        $(this).find('.gallery-slides').slick(optionsForGalleryFull(this));
    });

    $('.gallery-column').each(function(){
        $(this).find('.gallery-viewer').slick(optionsForGalleryViewer(this));
        $(this).find('.gallery-slides').slick(optionsForGalleryColumn(this));
    });

    $('.js-modal-gallery').on('shown.bs.modal', function(){
        $(this).find('.gallery-modal').each(function(){
            $(this).find('.gallery-viewer').slick(optionsForGalleryViewer(this));
            $(this).find('.gallery-slides').slick(optionsForGalleryModal(this));
        });
    });

    $('.js-modal-gallery').on('hidden.bs.modal', function(){
        $(this).find('.gallery-modal').each(function(){
            $(this).find('.gallery-viewer').slick('unslick');
            $(this).find('.gallery-slides').slick('unslick');
        });
    });
});
