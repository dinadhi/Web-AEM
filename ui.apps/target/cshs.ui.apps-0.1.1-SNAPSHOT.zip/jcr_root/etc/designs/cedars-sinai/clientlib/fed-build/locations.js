function geoSuccess(position) {
    $('#geo-lat').val(position.coords.latitude);
    $('#geo-lng').val(position.coords.longitude);
    $('#location-address').val('');
    $('#locations-filter-form').submit();
}

function geoError(error) {
    $('.js-request-geolocate').after('<span class="small"> (' + error.message + ')</span>');
    $('.js-request-geolocate').after('<span>Sorry, we were not able to locate you.</span>');
    $('.js-request-geolocate').detach();
}

$('#location-address').change(function(){
    $('#geo-lat').val('');
    $('#geo-lng').val('');
});

if ("geolocation" in navigator) {

    $('.js-request-geolocate').on('click', function(){
        navigator.geolocation.getCurrentPosition(geoSuccess, geoError);
    });

    $('.js-request-geolocate').show();
}

function handleLocationsResetDisplay() {
    //hide reset button when not needed
    var $specials = $('#locations-filter-form .js-location-specialties');
    var $address = $('#locations-filter-form .js-location-address');

    if(($specials.val() === "ALL" || $specials.val() !== null) || $address.val() !== ""){
        $('#locations-filter-form [type=reset]').removeClass('reset-hide');
    }
}

function handleHoursDropdownPosition($target) {
    var dest = $(window)[0].innerHeight / 3;
    var popoverDistanceToBottom;
    popoverDistanceToBottom = ($(window).scrollTop() + $(window).height()) - $target.siblings(".location__hours-dropdown__content").offset().top;

    if($target.is(':checked') && popoverDistanceToBottom < 100) {
        scrollTo($target, dest);
    }
}

$(function(){

    // location detail hours dropdown label update
    var today = new Date();
    var thisDayNum = today.getDay();
    var hoursString = $(".location__detail-meta [data-day="+ thisDayNum +"]").text();
    if(hoursString !== "") {
        $('.js-hours-dropdown-label').html( hoursString.split(',').join(',<br /> ') );
    }

    $("[data-day]").each(function(){
        var $day = $(this);
        $day.html($day.text().split(',').join(',<br /> '));
    });

    handleLocationsResetDisplay();
    $("#locations-filter-form :input").on('change', function(){
        handleLocationsResetDisplay();
    });

    $("#locations-filter-form [type=reset]").on('click', function(){
        $('#locations-filter-form [type=reset]').addClass('reset-hide');
    });

    $('.js-hours-dropdown-input').on('change', function(){
        handleHoursDropdownPosition($(this));
    });
});
