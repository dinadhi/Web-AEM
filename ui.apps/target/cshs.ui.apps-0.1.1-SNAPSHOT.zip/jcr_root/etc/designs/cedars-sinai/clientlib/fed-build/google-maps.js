function initMap() {  // eslint-disable-line no-unused-vars

    $('.js-google-map').each(function(){
        // https://developers.google.com/maps/documentation/javascript/reference

        var map;
        var latLng = {lat: $(this).data('lat'), lng: $(this).data('lng')};
        var zoom = parseInt($(this).data('zoom'),10) || 15;

        map = new google.maps.Map(this, {
            scrollwheel: false,
            center: latLng,
            zoom: zoom
        });

        var markers = $(this).data('markers');
        markers.forEach(function(markerJson){
            markerJson.map = map;
            var marker = new google.maps.Marker(markerJson);

            var address = markerJson.address.replace(/ /g, '+');
            var infoWindowHtml = $('<div />');
            infoWindowHtml.append('<div class="map-info-title">'+markerJson.title+'</div>');
            infoWindowHtml.append('<a class="map-info-link" href="https://www.google.com/maps/dir//'+address+'">Get Directions</a>');

            var infoWindow = new google.maps.InfoWindow({
                content: infoWindowHtml.html()
            });

            marker.addListener('click', function(){
                infoWindow.open(map, marker);
            });

            map.addListener('click', function(){
                infoWindow.close(map, marker);
            });
        });

    });
}
