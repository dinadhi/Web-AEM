$(function(){

    $('.carousel-full').on('beforeChange', function(event, slick, currentSlide, nextSlide){
        var isDark = $("[data-slick-index="+nextSlide+"]").hasClass('carousel-dark-background');

        if(isDark){
            $(this).addClass('carousel-dark-background');
        } else {
            $(this).removeClass('carousel-dark-background');
        }
    });

    $('.carousel-full').on('init', function(){
        var isDark = $("[data-slick-index=0]").hasClass('carousel-dark-background');

        if(isDark){
            $(this).addClass('carousel-dark-background');
        }
    });

    // carousel inits
    $('.carousel-slim:not(.carousel-edit)').slick({
        adaptiveHeight: true,
        dots: true,
        customPaging: function(slider, i) {
            return $('<button type="button" />').append($('<span />').text(i + 1));
        },
        prevArrow: '<button type="button" class="slick-prev"><span>Previous slide</span></button>',
        nextArrow: '<button type="button" class="slick-next"><span>Next slide</span></button>',
    });

    $('.carousel-full:not(.carousel-edit)').slick({
        adaptiveHeight: true,
        dots: true,
        customPaging: function(slider, i) {
            return $('<button type="button" />').append($('<span />').text(i + 1));
        },
        prevArrow: '<button type="button" class="slick-prev"><span>Previous slide</span></button>',
        nextArrow: '<button type="button" class="slick-next"><span>Next slide</span></button>',
    });

});
