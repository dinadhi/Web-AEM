function scrollTo(target, destination){
    if(!destination) {
        destination = 0;
    }

    if($(target).length > 0) {
        var offset = $(target).offset();

        $('html, body').stop().animate({
            scrollTop: offset.top - destination
        }, 300, 'linear');
    }
}

function jumpToAndOpenAccordianItem(){
    var url = window.location.href;
    var n = url.indexOf("#");

    if(n > -1){
        $anchor = $("#" + url.substr(n+1));

        if( $anchor.length > 0 ){
            $(".collapse").collapse('hide');
            $($anchor.attr('href')).collapse('show');
            scrollTo($anchor);
        }
    }
}


function updateBackToTop() {
    var scroll = $(window).scrollTop();
    var stickyNavHeight = $(".sticky-nav:visible").height() || 0;
    var floatStop = scroll + $(window).height() - stickyNavHeight;
    var footer = $("footer").offset().top + ($(".back-to-top").height() / 2);

    if(scroll > 65) {
        $(".js-back-to-top").addClass('on-screen');
    } else {
        $(".js-back-to-top").removeClass('on-screen');
    }

    if( (scroll > 65) && (floatStop > footer) ) {
        $(".js-back-to-top").addClass('at-bottom');
    } else {
        $(".js-back-to-top").removeClass('at-bottom');
    }
}

function animateSubnav() {
    var $subnav = $('.sub-nav'),
        $toggle = $('[type="checkbox"][id^="section-toggle"]', $subnav);

    if($toggle.is(':checked')) {

        $subnav.removeAttr('style');
        $subnav.animate({
            height: 'auto',
            maxHeight: '1000px'
        }, '144ms');
    } else {

        $subnav.animate({
            height: '56px',
            maxHeight: '56px'
        }, '144ms');
    }
}

$(function(){
    jumpToAndOpenAccordianItem();

    $("[href^='#']:not([data-toggle='collapse']):not([data-toggle='modal'])").on('click', function(){
        var target = $(this).attr('href');

        if( $(target).data('toggle') == 'collapse' ) {
            $(".collapse").collapse('hide');
            $($(target).attr('href')).collapse('show');
        }
        scrollTo($(target));
        // return false;
    });

    $(".js-back-to-top").on("click", function(){
        scrollTo($('body'));
    });

    $(window).on('scroll', updateBackToTop);

    // trigger animate subnav
    $('[type="checkbox"][id^="section-toggle"]', '.sub-nav').on('change', animateSubnav);
});
