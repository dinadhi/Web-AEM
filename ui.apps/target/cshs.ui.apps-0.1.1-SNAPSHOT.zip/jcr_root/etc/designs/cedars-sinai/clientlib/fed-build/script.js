function updateYTPlayerSrc(src) {
    // YouTube Video URL requirements
    //   * enablejsapi=1 parameter that allows api commands
    //   * rel=0 flag to prevent related video playing
    //   * local origin value set for tracking purposes
    // Example: https://www.youtube.com/embed/fIAkpMA54Do?rel=0&enablejsapi=1&origin=' + encodeURIComponent(location.origin)

    var $videoIframe = $(src).find('iframe');
    var url = $videoIframe.attr('src').replace('watch?v=', 'embed/') + '?rel=0&enablejsapi=1&origin=' + encodeURIComponent(location.origin);
    $videoIframe.prop('src', url);
}

$(function(){

    // alert-warning dismiss
    $('body').on('click', '.js-dismiss-warning', function(){
        // set session var here to prevent warning from returning for a duration
        $(this).closest('.system-alert').slideUp(750, function(){ $(this).detach(); });
    });

    // YouTube embed url management
    $('.fig-video').each(function(){ updateYTPlayerSrc(this); });

    // YouTube modal playback pause on close
    $('.js-modal-video').on('hidden.bs.modal', function() {
        $(this).find('iframe').each(function(){
            this.contentWindow.postMessage('{"event":"command","func":"' + 'pauseVideo' + '","args":""}', '*');
        });
    });

    // allows sub-nav to default to closed
    var $collapsable = $('.sub-nav .collapse');

    $collapsable.each(function(){
        $(this).on('show.bs.collapse', function(){
            var toggleId = $(this).attr('id');
            $('[href="#'+ toggleId +'"]').addClass('opened');
        });

        $(this).on('hide.bs.collapse', function(e){
            var toggleId = $(e.target).attr('id');
            $('[href="#'+ toggleId +'"]').removeClass('opened');
        });
    });

    // find current parents that need to default to opened
    $('.current')
        .parents('.sub-section-title')
        .find('.sub-section-toggle').addClass('opened');
    $('.current')
        .parents('.sub')
        .prev('.sub-section-title')
        .find('.sub-section-toggle').addClass('opened');

    var $currentUl = $('.current').closest('li').find('.collapse.in');

    $currentUl.find('.sub-section-title a').each(function () {
        if($(this).closest('ul').attr('id') === $currentUl.attr('id')) {
            $(this).addClass('sub-nav-bold');
        }
    });

    $(".expert-team-filters").on('change', function() {
        $(".expert-team-filters").submit();
    });
});
