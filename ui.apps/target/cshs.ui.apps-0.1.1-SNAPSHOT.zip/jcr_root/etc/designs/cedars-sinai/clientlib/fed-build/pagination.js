$(function(){
    var pageSubmit = function(pageId){
        $('#pgindex').val(pageId);
        $(".expert-team-filters").submit();
    };

    $('a.prev').click(function(){
        pageSubmit(""+(parseInt($('#pgindex').val())-1));
    });
    $('a.next').click(function(){
        pageSubmit(""+(parseInt($('#pgindex').val())+1));
    });

    var pageLinks = $('a.page-index');
    $.each(pageLinks, function (index, link) {
        $(link).click(function(){
            pageSubmit($(link).attr('data-click-value'));
        });
    });
});
