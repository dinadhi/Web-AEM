function isTouchDevice() {
    return 'ontouchstart' in window || navigator.maxTouchPoints;
}

function removeMegaTabindex(){
    $(".nav__global--item-container a").each(function(){
        $(this).attr('tabindex', '-1');
    });
}

function closeMegaMenuItem(src) {
    $(src).closest('.nav__global--item').removeClass('open');
    $('body').removeClass('has-mega-open');
    $('body').removeClass('has-scrollbar');
    removeMegaTabindex();
}

if(isTouchDevice()){ $('body').addClass('is-touch'); }
$(function(){
    $('#mobile-menu-open').on('click', function(){
        $('header').addClass('open').removeClass('search');
    });

    $('#mobile-menu-close').on('click', function(){
        $('header').removeClass('open');
    });

    $('#mobile-search-open').on('click', function(){
        $('header').addClass('search').removeClass('open');
    });

    $('#mobile-search-close').on('click', function(){
        $('header').removeClass('search');
    });


    // remove tabindex for mega menu links
    removeMegaTabindex();

    // desktop mega-menu toggler
    $('.nav__global--item > button').on('click', function(){
        var headerBottomPosition = $(this).position().top + $(this).height() + 34 - $('body').scrollTop();
        var wasOpen = $(this).closest('.nav__global--item').hasClass('open');
        $('.nav__global--item').removeClass('open');
        $('body').removeClass('has-mega-open');
        removeMegaTabindex();

        if( $(document).height() > $(window).height() ) {
            $('body').addClass('has-scrollbar');
        } else {
            $('body').removeClass('has-scrollbar');
        }

        if(wasOpen){
            $(this).focus();
        } else {
            $(this).closest('.nav__global--item').addClass('open');
            $('.open .nav__global--item-container').css("top", headerBottomPosition+"px");
            $('body').addClass('has-mega-open');

            // force a redraw to handle some IE painting issues.
            $('.nav__global--item.open .mega-menu-heading').focus();
            $(this).focus();

            $(this).closest('.nav__global--item').find('a:not(.mega-menu-heading)').each(function(){
                $(this).attr('tabindex', '0');
            });
        }
    });

    $('.mega-menu-heading').on('click', function(){
        closeMegaMenuItem(this);
    });

    $("body").on('click', '.open .nav__global--item-container', function(event){
        if( $(this)[0] == event.target ) {
            closeMegaMenuItem(event.target);
        }
    });
});
