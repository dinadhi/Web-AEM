$(document).ready(function() {
    if(getCookie("warning")== "remove"){
        $(".js-dismiss-warning").closest('.system-alert.warning').detach();
    }

    $('body').on('click', '.js-dismiss-warning', function(){
        deleteCookie("warning");
        setCookie("warning", "remove", 365);
    });
});

function getCookie(c_name) {
    if (document.cookie.length>0) {
        c_start=document.cookie.indexOf(c_name + "=");
        if (c_start!=-1) {
            c_start=c_start + c_name.length+1;
            c_end=document.cookie.indexOf(";",c_start);
            if (c_end==-1)
                c_end=document.cookie.length;
            return unescape(document.cookie.substring(c_start,c_end));
        }
    }
    return undefined;
}

function setCookie(c_name,value,expiredays) {
    var exdate = new Date();
    exdate.setDate(exdate.getDate() + expiredays);
    document.cookie = c_name + "=" + escape(value) + ((expiredays == null) ? "" : ";expires=" + exdate.toGMTString());
}


function deleteCookie(c_name){
    var exp = new Date();
    exp.setTime(exp.getTime() - 1);
    var cval=getCookie(c_name);
    if(cval!=null)
        document.cookie= c_name + "=" + cval + ";expires="+exp.toGMTString();
}
