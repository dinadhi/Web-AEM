var touchui = touchui || {};
touchui.contentblock = {};
(function(document, $) {

    var ariaInvalid = 'aria-invalid',
        isInvalidClass = ".is-invalid",
        isInvalid = 'is-invalid',
        ariaRequired = 'aria-required',
        ariaRequiredTrue = '[aria-required]',
        ariaInvalidTrue = '[aria-invalid]';


    touchui.contentblock.initialize = function() {
        panelShowHide();
        touchui.$dialog.on("selected", $("select[name='./layout']"), function() {
            panelShowHide();
        });

    };




    function panelShowHide() {
        var coralTabPanels = $('.coral-TabPanel-tab');
        var panel = $('.coral-TabPanel-pane');
        for (i = 1; i < coralTabPanels.length; i++) {
            $(coralTabPanels[i]).hide();


            $(panel[i]).find(ariaRequiredTrue).attr(ariaRequired, false);
            $(panel[i]).find(ariaInvalidTrue).removeAttr(ariaInvalid);
            $(panel[i]).find(isInvalidClass).removeClass(isInvalid);
        }
        var val = $("select[name='./layout']").val();


        if (val === 'standard') {
            $(coralTabPanels[1]).show();
            $(panel[1]).find(ariaRequiredTrue).attr(ariaRequired, true);
        } else if (val === 'icon') {
            $(coralTabPanels[2]).show();
            $(panel[2]).find(ariaRequiredTrue).attr(ariaRequired, true);
        } else if (val === 'meta') {
            $(coralTabPanels[4]).show();
            $(panel[4]).find(ariaRequiredTrue).attr(ariaRequired, true);
        } else if (val === 'svg') {
            $(coralTabPanels[3]).show();
            $(panel[3]).find(ariaRequiredTrue).attr(ariaRequired, true);
        }




    }


})(document, Granite.$);