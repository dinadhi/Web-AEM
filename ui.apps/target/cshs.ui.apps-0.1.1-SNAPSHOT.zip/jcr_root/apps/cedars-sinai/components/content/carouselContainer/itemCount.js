"use strict";
use(function () {
    var count = properties["slideCount"];
    if(typeof count == 'undefined' || count==null)
        count="4";
    var numArray= [];
    for(var i=0; i<Number(count);i++)
        numArray.push(i+1);
    return numArray;
});