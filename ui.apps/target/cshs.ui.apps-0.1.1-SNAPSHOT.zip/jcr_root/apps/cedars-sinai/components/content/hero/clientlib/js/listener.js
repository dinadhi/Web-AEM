(function(document, $,ns) {
    "use strict";
    function showHide(el){
        var hasImage = $(el).find("coral-select-item[value='fullImageContentBelow']").prop("selected")
            || $(el).find("coral-select-item[value='leftImageContentRight']").prop("selected")
            || $(el).find("coral-select-item[value='rightImageContentLeft']").prop("selected");
        var imageContainer = $(el).closest(".cq-dialog-content").find("input[name='./overlayImage']").closest(".coral-Form-fieldwrapper");
        if(hasImage){
            imageContainer.show();
        }else{
            imageContainer.hide();
        }
   }
    $(document).on("foundation-contentloaded", function(e) {
        $("coral-select[name='./layout']").each( function(){
        	showHide(this);
        });

    });

    $(document).on("change", "coral-select[name='./layout']", function(e) {
        showHide(this);
    });
})(document,Granite.$, Granite.author);