$(function(){
    $(".modal-dismiss").on('click',function(){
        var src = $("#iframeVideoModal").attr("src");
        $("#iframeVideoModal").attr("src",src+"?"+new Date());
    });
});
