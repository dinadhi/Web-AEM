var touchui = touchui || {};
(function (document, $) {
    
    touchui.initializeDialogReady = function () {
       
        var _resourceType = touchui.$dialog.find('[name="./sling:resourceType"]');
        if (_resourceType.length > 0) {
           var _resourceValue = _resourceType.attr('value');
            if (_resourceValue.indexOf('cedars-sinai/components/content/contentBlock') !== -1) {
            touchui.contentblock.initialize();
        }
        }
    };
    

    $(document).ready(function () {
        if ($('.cq-dialog-fullscreen').length > 0) {
            touchui.$dialog = $('.cq-dialog-fullscreen');
            touchui.initializeDialogReady();
        }

        $(document).on("dialog-ready", function () {
            touchui.$dialog = $('.cq-dialog-floating');
            touchui.initializeDialogReady();
        });
    });
})(document, Granite.$);
