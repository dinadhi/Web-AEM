(function(document, $,ns) {
    "use strict";
    function showHide(el){
        var isLinkList = $(el).find("coral-select-item[value='linklist']").prop("selected");;
        var isLinkAndImage = $(el).find("coral-select-item[value='linkAndImage']").prop("selected");;
            if(isLinkList){
				 var tabs = $(el).closest(".cq-dialog-content").find("coral-tab");
                for(var i=2;i<tabs.length;i++){
                    if(i<5){
                        $(tabs[i]).show();
                    }else{
						$(tabs[i]).hide();
                    }
                }
            }else if(isLinkAndImage){
				 var tabs = $(el).closest(".cq-dialog-content").find("coral-tab");
                for(var i=2;i<tabs.length;i++){
                    if(i<5){
                        $(tabs[i]).hide();
                    }else{
						$(tabs[i]).show();
                    }
                }
            }
   }
    $(document).on("foundation-contentloaded", function(e) {
        $("coral-select[name='./menuLayout']").each( function(){
        	showHide(this);
        });

    });

    $(document).on("change", "coral-select[name='./menuLayout']", function(e) {
        showHide(this);
    });
    var showError = function(msg){
		ns.ui.helpers.prompt({
                            title: Granite.I18n.get("Validation Failed"),
                            message: msg,
                            actions: [{
                                id: "CANCEL",
                                text: "CANCEL",
                                className: "coral-Button"
                            }],
                        callback: function (actionId) {
                            if (actionId === "CANCEL") {
                            }
                        }
                    });
    }
})(document,Granite.$, Granite.author);