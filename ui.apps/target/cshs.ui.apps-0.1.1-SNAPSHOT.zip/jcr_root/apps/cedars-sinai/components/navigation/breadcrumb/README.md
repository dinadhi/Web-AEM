
Breadcrumb 
====
Breadcrumb component written in HTL.

## Features
* Start level
* Option to hide breadcrumb


### Use Object
The Breadcrumb component uses the `org.cshs.aem.models.Breadcrumb` Sling model as its Use-object.

### Component policy configuration properties
The following configuration properties are used:

1. `./startLevel` - defines from which level relative to the current page the breadcrumbs will be rendered
2. `./hideBreadcrumb` - if set to `true` (checked by authors), breadcrumb will be not be displayed

### Edit dialog properties
The following properties are written to JCR for this Breadcrumb component and are expected to be available as `Resource` properties:

1. `./startLevel` - defines from which level relative to the current page this breadcrumb will render its items
2. `./hideBreadcrumb` - if set to `true` (checked by authors), breadcrumb will be not be displayed


## Information
* **Vendor**: Adobe
* **Version**: v1
* **Compatibility**: AEM 6.3
* **Status**: production-ready
* **Documentation**: [https://www.adobe.com/go/aem\_cmp\_breadcrumb\_v1](https://www.adobe.com/go/aem_cmp_breadcrumb_v1)

